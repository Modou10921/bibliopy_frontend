import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('access_token');

  if (token) {
    return true; // ✅ connecté → accès autorisé
  } else {
    router.navigate(['/connexion']); // ❌ non connecté → retour connexion
    return false;
  }
};